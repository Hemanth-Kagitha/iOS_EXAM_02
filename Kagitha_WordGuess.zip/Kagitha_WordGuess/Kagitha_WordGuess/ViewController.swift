//
//  ViewController.swift
//  Kagitha_WordGuess
//
//  Created by Hemanth Sai Kagitha on 10/16/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var guessButton: UIButton!
    
    
    @IBOutlet weak var playAgainButton: UIButton!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var words = [["CAR", "Automobile"],["Sun","Morning Star"],["FISH", "Aquatic animal"],["BICYCLE", "Two-wheeled transport"],["GUITAR", "Musical instrument with strings"]]
    
    var count = 0
    var word = ""
    var lettersGuessed = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        guessButton.isEnabled = false
        
        //Get the first word from the array
        word = words[count][0]
        
        userGuessLabel.text = ""
        
        
       
        
        updateUnderscores()
        
        //Get the first hint from the array
        hintLabel.text = "Hint: "+words[count][1]
        print(hintLabel.text!)
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        var letter = guessLetterField.text!
        
        guessButton.isEnabled = true
        
        //Replace the guessed letter if the letter is part of the word.
        lettersGuessed = lettersGuessed + letter
        
        var revealWord = ""
        for l in word{
            if lettersGuessed.contains(l){
                revealWord += "\(l)"
            }
            else{
                revealWord += "_ "
            }
        }
        print(word)
        //Assigning the word to displaylabel after a guess
        userGuessLabel.text = revealWord
        guessLetterField.text = ""
        
        if userGuessLabel.text!.contains("_") == false{
            playAgainButton.isHidden = false;
            guessButton.isEnabled = false;
        }
        guessButton.isEnabled = false
        
        
    }
    
    
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
    }
    
    
    @IBAction func guessLetterChanged(_ sender: Any) {
        //Read the data from the text field
        var textEnterd = guessLetterField.text!;
        
        //Consider only the last character by calling textEntered.last and trimming the white spaces.
        textEnterd = String(textEnterd.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = textEnterd
        
        if textEnterd.isEmpty {
            guessButton.isEnabled = false
        }
        else {
            guessButton.isEnabled = true
        }
    }
    
    
    
    func updateUnderscores(){
            for letter in word{
                userGuessLabel.text! += "_ "
            }
        }


}

